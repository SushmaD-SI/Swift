//
//  DetailsViewController.swift
//  Project
//
//  Created by User on 18/08/23.
//

import UIKit

class DetailsViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    
    var viewModel  : DetailsViewControllerVM = DetailsViewControllerVM()
     
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.nameinfo.text      = self.viewModel.nameinfo
        self.emailinfo.text     = self.viewModel.emailinfo
        self.eventinfo.text     = self.viewModel.eventinfo.description
        self.comfortinfo.text   = "\(self.viewModel.comfortinfo )"
        self.safetyinfo.text    = "\(self.viewModel.safetyinfo  )"
        self.securityinfo.text  = "\(self.viewModel.securityinfo )"
        self.dateinfo.text      = self.viewModel.eventinfo.description
        
        
    }
    
    @IBOutlet weak var nameinfo: UILabel!
    
    @IBOutlet weak var emailinfo: UILabel!

    @IBOutlet weak var eventinfo: UILabel!
    
    @IBOutlet weak var comfortinfo: UILabel!

    @IBOutlet weak var safetyinfo: UILabel!
    
    @IBOutlet weak var securityinfo: UILabel!
    
    @IBOutlet weak var dateinfo: UILabel!
    
}
