//
//  ResponseViewController.swift
//  Project
//
//  Created by User on 18/08/23.
//

import UIKit

class ResponseViewController: UITableViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false
        
        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }
    
    // MARK: - Table view data source
    var viewModel   : ResponsesTableViewControllerVM    =     ResponsesTableViewControllerVM()
    let segueID     : String                            = "moreDetails"
    let cellID      : String                            = "CELL"
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 0
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return 0
    }
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.viewModel.tableData.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: self.cellID, for: indexPath)
        
        var content = cell.defaultContentConfiguration()
        
        let rowData : Info = self.viewModel.tableData[indexPath.row]
        content.text            = rowData.text
        content.secondaryText   = rowData.eventDate.description
        cell.contentConfiguration = content
        
        return cell
    }
    
    //MARK: - Delegate methods
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.performSegue(withIdentifier: self.segueID, sender: self.viewModel.tableData[indexPath.row])
    }
    
    //MARK: - Navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == self.segueID {
            let destination : DetailsViewController = segue.destination as! DetailsViewController
            destination.viewModel.nameinfo     = (sender as! Info).name
            destination.viewModel.emailinfo     = (sender as! Info).email
            destination.viewModel.phoneinfo     = (sender as! Info).phone
            destination.viewModel.eventinfo    = (sender as!  Info).event
                .description
            destination.viewModel.comfortinfo    = (sender as! Info).comfort
            destination.viewModel.safetyinfo     = (sender as! Info).safety
            destination.viewModel.securityinfo     = (sender as! Info).security
        }
        
        
        
    }
}
