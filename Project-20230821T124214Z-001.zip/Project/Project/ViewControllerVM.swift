//
//  ViewControllerVM.swift
//  Project
//
//  Created by User on 17/08/23.
//

import Foundation


class ViewControllerVM
{
var name       : String    = ""
var email      : String    = ""
var phone      : String    = ""
var datepicker : Date      = Date.now
var comfort    : Int       = 0
var safety     : Int       = 0
var security   : Int       = 0

func save()


{
    DataModelController.shared.save(newInfo: Info  (name        : self.name,
                                                    email       : self.email,
                                                    phone       : self.phone ,
                                                    datepicker  : self.datepicker,
                                                    comfort     : self.comfort ,
                                                    safety      : self.safety,
                                                    security    : self.security))
     
    
    
}

}
