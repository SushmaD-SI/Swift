//
//  ViewController.swift
//  Project
//
//  Created by User on 16/08/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    var viewModel : ViewControllerVM = ViewControllerVM()

    @IBOutlet weak var name: UITextField!
    
    @IBOutlet weak var Email: UITextField!
    
    @IBOutlet weak var phone: UITextField!
    
    //var viewModel: ViewControllerVM = ViewControllerVM()
    
    
    @IBOutlet weak var datepicker: UIDatePicker!
    
    @IBOutlet weak var comfort: UISegmentedControl!
    
    
    @IBOutlet weak var safety: UISegmentedControl!
    
    
    @IBOutlet weak var security: UISegmentedControl!
    

    
    @IBAction func Save(_ sender: Any) {
        self.viewModel.name        = self.name.text!
        self.viewModel.email       = self.Email.text!
        self.viewModel.phone       = self.phone.text!
        self.viewModel.datepicker  = self.datepicker.date
        self.viewModel.comfort     = self.comfort.selectedSegmentIndex
        self.viewModel.safety      = self.safety.selectedSegmentIndex
        self.viewModel.security    = self.security.selectedSegmentIndex
        
        self.viewModel.save()
    }
    
    
    
    @IBAction func cancel(_ sender: Any) {
    }
    
    
    
    @IBAction func bookmark(_ sender: Any) {
    }
    
}

