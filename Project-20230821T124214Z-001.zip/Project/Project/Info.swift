//
//  Info.swift
//  Project
//
//  Created by User on 18/08/23.
//

import Foundation

struct Info {
    var name       : String    = ""
    var email      : String    = ""
    var phone      : String    = ""
    var datepicker : Date      = Date.now
    var comfort    : Int       = 0
    var safety     : Int       = 0
    var security   : Int       = 0
    
}

extension Info : Codable {
    
}

extension Info : CustomStringConvertible {
    var description: String {
        """
        Info
        -----
        Name:       \(self.name)
        EMAIL:      \(self.email)
        PHONE:      \(self.phone)
        DATE:       \(self.datepicker)
        COMFORT     \(self.comfort)
        SAFETY      \(self.safety)
        SECURITY    \(self.security)
        """
    }
}
