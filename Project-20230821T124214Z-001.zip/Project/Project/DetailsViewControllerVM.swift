//
//  DetailsViewControllerVM.swift
//  Project
//
//  Created by User on 18/08/23.
//

import Foundation
class DetailsViewControllerVM {
    var nameinfo       : String       = ""
    var emailinfo      : String       = ""
    var phoneinfo      : String       = ""
    var eventinfo      :  Date        = Date.now
    var comfortinfo    : Int          = 0
    var safetyinfo     : Int          = 0
    var securityinfo   : Int          = 0
    
}

